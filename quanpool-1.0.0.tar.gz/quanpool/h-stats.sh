#!/usr/bin/env bash

# Query quanpool-miner's built-in /hive-stats endpoint (default port 9900)
stats_raw=$(curl -s --connect-timeout 2 --max-time 5 "http://127.0.0.1:9900/hive-stats")

if [[ $? -ne 0 || -z "$stats_raw" ]]; then
  stats="null"
  khs=0
else
  # If stats endpoint returns json directly formatted for hiveos:
  stats=$(echo "$stats_raw" | jq -c '{hs: .hs, hs_units: (.hs_units // "khs"), temp: .temp, fan: .fan, uptime: .uptime, ar: .ar, bus_numbers: .bus_numbers, algo: (.algo // "quantus")}')
  khs=$(echo "$stats_raw" | jq -r '.khs // 0')
fi

[[ -z "$khs" ]] && khs=0
[[ -z "$stats" ]] && stats="null"
