#!/usr/bin/env bash
cd /hive/miners/custom/quanpool
. h-manifest.conf
mkdir -p /var/log/miner/custom
conf=""
[[ -f "$CUSTOM_CONFIG_FILENAME" ]] && conf=$(cat "$CUSTOM_CONFIG_FILENAME")
[[ -z "$conf" ]] && conf="serve"
eval "./quanpool-miner $conf 2>&1 | tee ${CUSTOM_LOG_BASENAME}.log"
