#!/usr/bin/env bash

cd /hive/miners/custom/quanpool

. h-manifest.conf

[[ `ps aux | grep "quanpool-miner" | grep -v grep | wc -l` != 0 ]] &&
  echo "quanpool is already running" &&
  exit 1

conf=""
if [[ -f "$CUSTOM_CONFIG_FILENAME" ]]; then
  conf=$(cat "$CUSTOM_CONFIG_FILENAME")
fi

[[ -z "$conf" ]] && conf="serve"

mkdir -p $(dirname "$CUSTOM_LOG_BASENAME")

eval "./quanpool-miner $conf 2>&1 | tee ${CUSTOM_LOG_BASENAME}.log"
