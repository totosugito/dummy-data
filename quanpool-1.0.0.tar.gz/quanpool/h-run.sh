#!/usr/bin/env bash

cd /hive/miners/custom/quanpool

. h-manifest.conf

[[ `ps aux | grep "quanpool-miner" | grep -v grep | wc -l` != 0 ]] &&
  echo "quanpool is already running" &&
  exit 1

[[ ! -f "$CUSTOM_CONFIG_FILENAME" ]] && echo "Config file $CUSTOM_CONFIG_FILENAME not found" && exit 1

PARAMS=$(cat "$CUSTOM_CONFIG_FILENAME")

mkdir -p $(dirname "$CUSTOM_LOG_BASENAME")

./quanpool-miner $PARAMS 2>&1 | tee "${CUSTOM_LOG_BASENAME}.log"
