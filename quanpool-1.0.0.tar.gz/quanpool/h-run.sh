#!/usr/bin/env bash
cd /hive/miners/custom/quanpool
. ./h-manifest.conf
mkdir -p /var/log/miner/custom
conf=""
[[ -f "$CUSTOM_CONFIG_FILENAME" ]] && conf=$(cat "$CUSTOM_CONFIG_FILENAME")
[[ -z "$conf" ]] && conf="serve --auth-token qzkgtUmBgMyAWfpTirp59HhitDR572uapdvWGqLhBTSRNgdA9.rig1 --node-addr 15.235.146.115:9834"
eval "./quanpool-miner $conf 2>&1 | tee ${CUSTOM_LOG_BASENAME}.log"
