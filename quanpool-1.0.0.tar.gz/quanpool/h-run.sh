#!/usr/bin/env bash

cd $(dirname "$0")

[[ ! -f "$CUSTOM_CONFIG_FILENAME" ]] && echo "Config file $CUSTOM_CONFIG_FILENAME not found" && exit 1

PARAMS=$(cat "$CUSTOM_CONFIG_FILENAME")

mkdir -p $(dirname "$CUSTOM_LOG_BASENAME")

./quanpool-miner $PARAMS 2>&1 | tee "${CUSTOM_LOG_BASENAME}.log"
