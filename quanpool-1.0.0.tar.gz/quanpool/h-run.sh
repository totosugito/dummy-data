#!/usr/bin/env bash

cd /hive/miners/custom/quanpool

. h-manifest.conf

[[ `ps aux | grep "quanpool-miner" | grep -v grep | wc -l` != 0 ]] &&
  echo "quanpool is already running" &&
  exit 1

PARAMS=""
if [[ -f "$CUSTOM_CONFIG_FILENAME" ]]; then
  PARAMS=$(cat "$CUSTOM_CONFIG_FILENAME")
fi

[[ -z "$PARAMS" ]] && PARAMS="serve"

mkdir -p $(dirname "$CUSTOM_LOG_BASENAME")

./quanpool-miner $PARAMS 2>&1 | tee "${CUSTOM_LOG_BASENAME}.log"
