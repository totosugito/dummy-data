#!/usr/bin/env bash

function miner_config_gen() {
  local MINER_DIR=$(dirname "$BASH_SOURCE")
  [[ -z "$CUSTOM_CONFIG_FILENAME" ]] && CUSTOM_CONFIG_FILENAME="/hive/miners/custom/quanpool/quanpool.conf"
  local auth_arg=""
  if [[ -n "$CUSTOM_TEMPLATE" ]]; then
    if [[ -n "$CUSTOM_WORKER" ]]; then
      auth_arg="--auth-token ${CUSTOM_TEMPLATE}.${CUSTOM_WORKER}"
    else
      auth_arg="--auth-token ${CUSTOM_TEMPLATE}"
    fi
  fi
  local node_arg=""
  if [[ -n "$CUSTOM_URL" ]]; then
    node_arg="--node-addr ${CUSTOM_URL}"
  fi
  echo "serve ${auth_arg} ${node_arg} ${CUSTOM_USER_CONFIG}" > "$CUSTOM_CONFIG_FILENAME"
}

miner_config_gen
