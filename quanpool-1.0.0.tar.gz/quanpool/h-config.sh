#!/usr/bin/env bash

function miner_config_gen() {
  [[ -z "$CUSTOM_CONFIG_FILENAME" ]] && CUSTOM_CONFIG_FILENAME="/hive/miners/custom/quanpool/quanpool.conf"
  
  local auth_arg=""
  if [[ -n "$CUSTOM_TEMPLATE" ]]; then
    if [[ -n "$CUSTOM_WORKER" ]]; then
      auth_arg="--auth-token ${CUSTOM_TEMPLATE}.${CUSTOM_WORKER}"
    else
      auth_arg="--auth-token ${CUSTOM_TEMPLATE}"
    fi
  fi

  local node_arg=""
  if [[ -n "$CUSTOM_URL" ]]; then
    node_arg="--node-addr ${CUSTOM_URL}"
  fi

  # Filter out any foreign miner arguments like --algorithm, --wallet, --worker, --pool
  local user_cfg="${CUSTOM_USER_CONFIG}"
  user_cfg=$(echo "$user_cfg" | sed -E 's/--algorithm(-gpu)?[[:space:]]+[^[:space:]]+//g')
  user_cfg=$(echo "$user_cfg" | sed -E 's/--wallet[[:space:]]+[^[:space:]]+//g')
  user_cfg=$(echo "$user_cfg" | sed -E 's/--worker[[:space:]]+[^[:space:]]+//g')
  user_cfg=$(echo "$user_cfg" | sed -E 's/--pool[[:space:]]+[^[:space:]]+//g')
  user_cfg=$(echo "$user_cfg" | sed -E 's/--algo[[:space:]]+[^[:space:]]+//g')

  echo "serve ${auth_arg} ${node_arg} ${user_cfg}" | tr -s ' ' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' > "$CUSTOM_CONFIG_FILENAME"
}

miner_config_gen
