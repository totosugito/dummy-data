#!/usr/bin/env bash

function miner_config_gen() {
  [[ -z "$CUSTOM_CONFIG_FILENAME" ]] && CUSTOM_CONFIG_FILENAME="/hive/miners/custom/quanpool/quanpool.conf"
  local auth_arg=""
  if [[ -n "$CUSTOM_TEMPLATE" ]]; then
    if [[ -n "$CUSTOM_WORKER" ]]; then
      auth_arg="--auth-token ${CUSTOM_TEMPLATE}.${CUSTOM_WORKER}"
    else
      auth_arg="--auth-token ${CUSTOM_TEMPLATE}"
    fi
  fi
  local node_arg=""
  if [[ -n "$CUSTOM_URL" ]]; then
    node_arg="--node-addr ${CUSTOM_URL}"
  fi
  # Clean extra args: filter out incompatible flags like --algorithm-gpu, --wallet, --worker, --pool
  local clean_args=""
  if [[ -n "$CUSTOM_USER_CONFIG" ]]; then
    clean_args=$(echo "$CUSTOM_USER_CONFIG" | sed -E 's/--algorithm(-gpu)? [^ ]+//g; s/--wallet [^ ]+//g; s/--worker [^ ]+//g; s/--pool [^ ]+//g; s/--algo [^ ]+//g')
  fi
  echo "serve ${auth_arg} ${node_arg} ${clean_args}" | tr -s ' ' > "$CUSTOM_CONFIG_FILENAME"
}

miner_config_gen
