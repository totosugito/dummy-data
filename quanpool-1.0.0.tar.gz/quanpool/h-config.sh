#!/usr/bin/env bash
. `dirname $BASH_SOURCE`/h-manifest.conf
[[ -z $CUSTOM_CONFIG_FILENAME ]] && exit 1
AUTH_ARG=""
if [[ ! -z "$CUSTOM_TEMPLATE" ]]; then
  if [[ ! -z "$CUSTOM_WORKER" ]]; then
    AUTH_ARG="--auth-token ${CUSTOM_TEMPLATE}.${CUSTOM_WORKER}"
  else
    AUTH_ARG="--auth-token ${CUSTOM_TEMPLATE}"
  fi
fi
NODE_ARG=""
if [[ ! -z "$CUSTOM_URL" ]]; then
  NODE_ARG="--node-addr ${CUSTOM_URL}"
fi
echo "serve ${AUTH_ARG} ${NODE_ARG} ${CUSTOM_USER_CONFIG}" > "$CUSTOM_CONFIG_FILENAME"
